Python package that can be used to reproduce the figures and tables presented in [Prado, E.B., Nemeth, C. & Sherlock, C. Metropolis-Hastings with Scalable Subsampling. arxiv (2024)][mhss_paper].

[mhss_paper]: https://arxiv.org/pdf/2407.19602